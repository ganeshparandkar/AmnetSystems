import PyPDF2
from PyPDF2 import pdf
from django.http.response import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, HttpResponse, redirect

from .forms import FilesUploadForm
from .models import file_upload

# Create your views here.


def index(request):
    if request.method == 'POST':
        c_form = FilesUploadForm(request.POST, request.FILES)
        if c_form.is_valid():
            name = c_form.cleaned_data['file_name']
            files = c_form.cleaned_data['files']
            file_upload(file_name=name, up_file=files).save()

            return redirect('view')
        else:
            return HttpResponse("Error")

    else:
        context = {
            'form': FilesUploadForm()
        }
        return render(request, 'index.html', context)


def show_file(request):
    all_data = file_upload.objects.all()
    data = file_upload.objects.first()

    a = '.' + data.up_file.url
    file = open(a, "rb")
    reader = PyPDF2.PdfFileReader(file)
    print(a)
    page1 = reader.getPage(0)
    pdfData = reader.extractText()

    words = pdfData.split(' ')
    print(words)

    
    context = {
        'data': all_data,
        'pdfData': words
        
    }

    return render(request, 'view.html', context)
